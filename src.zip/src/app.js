/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  View,
  Dimensions
} from 'react-native';

import {Provider} from 'react-redux'
import { Router, Scene, ActionConst, Actions} from 'react-native-router-flux';
import LocationFinder from './components/LocationFinder'
import PlanList from './components/PlanList'
import PlanItem from './components/PlanItem'
import PlanEditor from './components/PlanEditor'
import LocationEditor from './components/LocationEditor'
import FriendList from './components/FriendList'

import enclose from 'circle-enclose';
import clusterfck from 'clusterfck';

import configureStore from './utils/configureStore';

import * as types from './actions/ActionTypes';
import * as actions from './actions/Actions'

const store = configureStore();

export default class Recommander extends Component {
  constructor(props) {
    super(props);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        console.log(position);
      },
      (error) => {
        alert(error.message);
      },
    )
  }

  componentDidMount() {
    circle = enclose([
      {x: -5, y: 0, r: 5},
      {x: 0, y: 0.5, r: 2},
      {x: 5, y: 55, r: 5}
    ])
    colors = [
       [20, 20, 80],
       [22, 22, 90],
       [250, 255, 253],
       [0, 30, 70],
       [200, 0, 23],
       [100, 54, 100],
       [255, 13, 8]
    ];
     
    // Calculate clusters. 
    clusters = clusterfck.kmeans(colors, 3);


    console.log(circle.r);
    console.log(circle.x);
    console.log(circle.y);    
    console.log(clusters);   

    console.log(store.getState());
    this.unsubscribe = store.subscribe(() => console.log(store.getState()))
    store.dispatch(actions.updatePlans(
      {plans: []}
    ));
  }

  componentWillUnmount() {
    this.unsubscribe()
  }

  render() {
    return (
      <Provider store={store}>
        <Router>
          <Scene key="root">   
            <Scene key="PlanList"
                   navigationBarStyle={{ backgroundColor: "rgba(52,84,127,1.0)" }} 
                   title="Travel Plan"
                   titleStyle={{ color: 'white' }}
                   component={PlanList} type={ActionConst.REPLACE} initial={true}/>
            <Scene key="FriendList"
                   component={FriendList}
                   hideNavBar
                   direction='vertical'/>
            <Scene key="PlanItem"
                   navigationBarStyle={{ backgroundColor: "rgba(52,84,127,1.0)" }} 
                   title="Travel Plan Item"
                   titleStyle={{ color: 'white' }}
                   hideBackImage={true}
                   backTitle="<"
                   backButtonTextStyle={{ color: 'white', fontWeight: 'bold' }}
                   component={PlanItem}
                   />
            <Scene key="PlanEditor"
                   navigationBarStyle={{ backgroundColor: "rgba(52,84,127,1.0)" }} 
                   title="Travel Plan Item"
                   titleStyle={{ color: 'white' }}
                   hideBackImage={true}
                   backTitle="<"
                   backButtonTextStyle={{ color: 'white', fontWeight: 'bold' }}
                   component={PlanEditor}
                   duration={600} />
            <Scene key="LocationEditor"
                   navigationBarStyle={{ backgroundColor: "rgba(52,84,127,1.0)" }} 
                   title="Location Editor"
                   titleStyle={{ color: 'white' }}
                   hideBackImage={true}
                   backTitle="<"
                   backButtonTextStyle={{ color: 'white', fontWeight: 'bold'}}
                   component={LocationEditor} 
                   hideNavBar={false}/>
            <Scene key="LocationFinder" component={LocationFinder} duration={600} hideNavBar/>
          </Scene>
        </Router>
      </Provider>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 30,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(52,84,127,1.0)'
  },
});

AppRegistry.registerComponent('Recommander', () => Recommander);
