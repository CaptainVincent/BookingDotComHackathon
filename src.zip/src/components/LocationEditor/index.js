import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
  Button,
} from 'react-native';

import {Actions} from 'react-native-router-flux';

export default class LocationEditor extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Text>LocationEditor</Text>
        <Button onPress={()=>{Actions.pop({popNum: 2});}} title='Test me'/>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    backgroundColor: '#444444'
  },
});
