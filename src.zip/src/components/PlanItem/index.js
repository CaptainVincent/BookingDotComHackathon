import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  ListView,
  Text,
  TouchableOpacity,
  TouchableHighlight,
  Dimensions,
} from 'react-native';

import { connect } from 'react-redux';
import { SwipeListView, SwipeRow } from 'react-native-swipe-list-view';
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/Ionicons';
import {Actions} from 'react-native-router-flux';

const deviceScreen = Dimensions.get('window');

class PlanItem extends Component {
  constructor(props) {
    super(props);
    this.ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    console.log(props.plans);
    this.state = {
      dataSource: ['a', 'b', 'c'],
      listViewData: Array(8).fill('').map((_,i)=>`item #${i}`)
    };
  }

  deleteRow(secId, rowId, rowMap) {
    rowMap[`${secId}${rowId}`].closeRow();
    const newData = [...this.state.listViewData];
    newData.splice(rowId, 1);
    this.setState({listViewData: newData});
  }

  _renderSeparator(sectionID: number, rowID: number, adjacentRowHighlighted: bool) {
    return (
      <View
        key={`${sectionID}-${rowID}`}
        style={{
          height: 1,
          left: 20,
          width: deviceScreen.width-40,
          backgroundColor: '#CCCCCC',
        }}
      />
    );
  }

  render() {
    return (
      <View style={styles.container}>
        <SwipeListView
          style={{height: deviceScreen.height-200}}
          dataSource={this.ds.cloneWithRows(this.state.listViewData)}
          renderSeparator={this._renderSeparator}
          enableEmptySections={true}
          renderRow={ data => (
            <TouchableHighlight
              onPress={ _ => {Actions.PlanItem()} }
              style={styles.rowFront}
              underlayColor={'#AAA'}
            >
              <View>
                <Text style={styles.name}>Tokyo</Text>
                <Text style={styles.note} numberOfLines={3}>I am {data} in a SwipeListView</Text>
              </View>
            </TouchableHighlight>
          )}
          renderHiddenRow={ (data, secId, rowId, rowMap) => (
            <View style={styles.rowBack}>
              <TouchableOpacity style={[styles.backBtn, styles.backLeftBtn]} onPress={ _ => this.deleteRow(secId, rowId, rowMap) }>
                <Icon name="md-trending-up" style={styles.icon} />
                <Text style={styles.backTextWhite}>Trend</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.backBtn, styles.backRightBtnLeft]} onPress={ _ => {Actions.LocationEditor()} }>
                <Icon name="ios-create" style={styles.icon} />
                <Text style={styles.backTextWhite}>Edit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.backBtn, styles.backRightBtnRight]} onPress={ _ => this.deleteRow(secId, rowId, rowMap) }>
                <Icon name="ios-trash" style={styles.icon} />
                <Text style={styles.backTextWhite}>Delete</Text>
              </TouchableOpacity>
            </View>
          )}
          leftOpenValue={75}
          rightOpenValue={-150}
        />
        <View pointerEvents={'box-none'} 
              style={{                  
                flex: 1,
                backgroundColor: '#FFF'
              }}
        >
          <ActionButton buttonColor="#547983">
            <ActionButton.Item buttonColor='rgb(28,28,28)' onPress={() => console.log("notes tapped!")}>
              <Icon name="md-help-circle" style={styles.actionButtonIcon} />
            </ActionButton.Item>
            <ActionButton.Item buttonColor='rgb(28,28,28)' title="Add Location" onPress={() => {Actions.LocationFinder();}}>
              <Icon name="ios-map" style={styles.actionButtonIcon} />
            </ActionButton.Item>
            <ActionButton.Item buttonColor='rgb(28,28,28)' title="Recommand Hotel" onPress={() => {Actions.pop();}}>
              <Icon name="md-home" style={styles.actionButtonIcon} />
            </ActionButton.Item>
          </ActionButton>
        </View> 
      </View>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    plans: state.db.plans,
  }
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 65,
    backgroundColor: 'white',
    flex: 1
  },
  backTextWhite: {
    color: '#FFF'
  },
  rowFront: {
    paddingLeft: 20,
    backgroundColor: '#FFF',
    justifyContent: 'center',
    height: 100,
  },
  rowBack: {
    alignItems: 'center',
    backgroundColor: '#DDD',
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingLeft: 15,
  },
  backBtn: {
    alignItems: 'center',
    bottom: 0,
    justifyContent: 'center',
    position: 'absolute',
    top: 0,
    width: 75,
  },
  backLeftBtn: {
    backgroundColor: '#0076FF',
  },
  backRightBtnLeft: {
    backgroundColor: '#F9A124',
    right: 75
  },
  backRightBtnRight: {
    backgroundColor: 'red',
    right: 0
  },
  icon: {
    fontSize: 30,
    height: 35,
    color: 'white',
  },
  actionButtonIcon: {
    fontSize: 25,
    height: 30,
    color: 'white',
  },
  name: {
    fontSize: 18,
    color: '#3C4F5E',
  },
  note: {
    fontSize: 14,
    color: '#6C7B8A',
  },
});

export default connect(mapStateToProps)(PlanItem);