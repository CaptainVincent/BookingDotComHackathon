import * as types from './ActionTypes';
//import Database from '../utils/Database';
import store from 'react-native-simple-store';

function requestDb(dbName) {
  return {
    type: types.REQUEST,
    dbName
  }
}

function invalidateDb(dbName) {
  return {
    type: types.INVALIDATE,
    dbName
  }
}

function receiveDb(dbName, data, timestamp) {
  return {
    type: types.RECEIVE,
    dbName,
    items: data,
    receivedAt: timestamp,
  }
}

export function updatePlans(plans) {
  return {
    type: types.UPDATE_PLAN,
    plans
  };
}
