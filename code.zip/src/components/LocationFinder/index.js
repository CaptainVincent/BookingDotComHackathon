import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Dimensions,
  Animated
} from 'react-native';

import { connect } from 'react-redux';
import * as actions from '../../actions/Actions'
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import MapView from 'react-native-maps';
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/Ionicons';
import {Actions} from 'react-native-router-flux';
import Spinner from 'react-native-spinkit';
import Prompt from 'react-native-prompt';

const deviceScreen = Dimensions.get('window');
const ASPECT_RATIO = deviceScreen.width / deviceScreen.height;
const LATITUDE = 25.0454863;
const LONGITUDE = 121.5289386;
const LATITUDE_DELTA = 0.02;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
const SPACE = 0.01;

function createMarker(modifier = 1) {
  return {
    latitude: LATITUDE - (SPACE * modifier),
    longitude: LONGITUDE - (SPACE * modifier),
  };
}

const DEFAULT_PADDING = { top: 40, right: 40, bottom: 40, left: 40 };

const mapStyle = [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#242f3e"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#746855"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#242f3e"
      }
    ]
  },
  {
    "featureType": "administrative.locality",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#d59563"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#d59563"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#263c3f"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#6b9a76"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#38414e"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#212a37"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9ca5b3"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#746855"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#1f2835"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#f3d19c"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#2f3948"
      }
    ]
  },
  {
    "featureType": "transit.station",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#d59563"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#17263c"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#515c6d"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#17263c"
      }
    ]
  }
];

class LocationFinder extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      mask: '#25303D',
      region: {
        latitude: LATITUDE,
        longitude: LONGITUDE,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      },
      defaultText: '',
      promptVisible: false,
    };
  }

  componentDidMount(){
    setTimeout(()=> {this.setState({loading: false})}, 500);
    setTimeout(()=> {this.setState({mask: 'rgba(0,0,0,0)'})}, 1000);
  }

  fitAllMarkers() {
    this.map.fitToCoordinates(MARKERS, {
      edgePadding: DEFAULT_PADDING,
      animated: true,
    });
  }
/*
  onLocationChange() {
    region = {
      latitude: this.state.region.latitude+5,
      longitude: this.state.region.longitude+5,
      latitudeDelta: this.state.region.latitudeDelta,
      longitudeDelta: this.state.region.longitudeDelta,
    }
    this.setState({ region });
  }*/

  onRegionChange(region) {
    if(this.state.mask != 'rgba(0,0,0,0)')
      return;
    this.setState({ region });
  }

  convertRegion(latitude, longitude) {
    const { region } = this.state;
    _region = {
      ...this.state.region,
      latitude: latitude,
      longitude: longitude,
    };
    return _region;
  }

  animateRegion(latitude, longitude) {
    this.map.animateToRegion(this.convertRegion(latitude, longitude));
  }

  renderLoading() {
    return (
      <View style={styles.spinner}>
        <Spinner isVisible={true}
                 size={70}
                 type={'FadingCircle'}
                 color={'#3C4F5E'}/>
          <GooglePlacesAutocomplete
            placeholder='Search Location'
            minLength={2} // minimum length of text to search
            autoFocus={false}
            listViewDisplayed='auto'    // true/false/undefined
            fetchDetails={true}
            renderDescription={(row) => row.description} // custom description render
            onPress={(data, details = null) => { // 'details' is provided when fetchDetails = true
              console.log(details.geometry.location);
            }}
            getDefaultValue={() => {
              return ''; // text input default value
            }}
            query={{
              // available options: https://developers.google.com/places/web-service/autocomplete
              key: 'AIzaSyCEMyKZa5uTj06-q5Co1qVgsomGo5l1TEA',
              //language: 'zh-tw',
              language: 'en', // language of the results
              //types: '(cities)', // default: 'geocode'
            }}
            styles={{
              container: {
                position: 'absolute',
                top: 30,
                left: 10,
                width: deviceScreen.width - 20,
              },
              description: {
                fontWeight: 'bold',
              },
              textInputContainer: {
                backgroundColor: 'rgba(0,0,0,0)',
                borderTopWidth: 0,
                borderBottomWidth:0
              },
              textInput: {
                marginLeft: 0,
                marginRight: 0,
                height: 38,
                color: '#2A2A2A',
                backgroundColor: 'rgba(255,255,255,0.7)',
                fontSize: 16
              },
              listView: {
                backgroundColor: 'rgba(255,255,255,0.7)',
              },
              poweredContainer: {
                backgroundColor: 'rgba(255,255,255,0.2)',
              },
              predefinedPlacesDescription: {
                color: '#2B60DB',
              },
            }}

            currentLocation={false} // Will add a 'Current location' button at the top of the predefined places list
            currentLocationLabel="Current location"
            nearbyPlacesAPI='GooglePlacesSearch' // Which API to use: GoogleReverseGeocoding or GooglePlacesSearch
            GoogleReverseGeocodingQuery={{
              // available options for GoogleReverseGeocoding API : https://developers.google.com/maps/documentation/geocoding/intro
            }}
            GooglePlacesSearchQuery={{
              // available options for GooglePlacesSearch API : https://developers.google.com/places/web-service/search
              rankby: 'distance',
            }}
            filterReverseGeocodingByTypes={['locality', 'administrative_area_level_3']} // filter the reverse geocoding results by types - ['locality', 'administrative_area_level_3'] if you want to display only cities
            debounce={200} // debounce the requests in ms. Set to 0 to remove debounce. By default 200ms.
          />
          <ActionButton buttonColor="#547983">
            <ActionButton.Item buttonColor='rgb(28,28,28)' onPress={() => console.log("notes tapped!")}>
              <Icon name="md-help-circle" style={styles.actionButtonIcon} />
            </ActionButton.Item>
            <ActionButton.Item buttonColor='rgb(28,28,28)' title="Select Location" onPress={() => console.log("notes tapped!")}>
              <Icon name="md-checkbox" style={styles.actionButtonIcon} />
            </ActionButton.Item>
            <ActionButton.Item buttonColor='rgb(28,28,28)' title="Cancel" onPress={() => {Actions.pop();}}>
              <Icon name="ios-undo" style={styles.actionButtonIcon} />
            </ActionButton.Item>
          </ActionButton>
      </View>
    );
  }

  render() {
    if (this.state.loading) {
      return this.renderLoading();
    }
    else
    {
      return (
        <MapView
          ref={ref => { this.map = ref; }}
          provider={MapView.PROVIDER_GOOGLE}
          customMapStyle={mapStyle}
          style={{
            backgroundColor: '#25303D',
            ...StyleSheet.absoluteFillObject,
          }}
          region={this.state.region}
          onRegionChange={region => this.onRegionChange(region)}
          >
          <View style={{...StyleSheet.absoluteFillObject}} 
                pointerEvents={'box-none'}
                backgroundColor={this.state.mask}
          >
            <GooglePlacesAutocomplete
              placeholder='Search Location'
              minLength={2} // minimum length of text to search
              autoFocus={false}
              listViewDisplayed='auto'    // true/false/undefined
              fetchDetails={true}
              renderDescription={(row) => row.description} // custom description render
              onPress={(data, details = null) => { // 'details' is provided when fetchDetails = true
                this.animateRegion(details.geometry.location.lat, details.geometry.location.lng);
              }}
              getDefaultValue={() => {
                return ''; // text input default value
              }}
              query={{
                // available options: https://developers.google.com/places/web-service/autocomplete
                key: 'AIzaSyCEMyKZa5uTj06-q5Co1qVgsomGo5l1TEA',
                //language: 'zh-tw',
                language: 'en', // language of the results
                //types: '(cities)', // default: 'geocode'
              }}
              styles={{
                container: {
                  position: 'absolute',
                  top: 30,
                  left: 10,
                  width: deviceScreen.width - 20,
                },
                description: {
                  fontWeight: 'bold',
                },
                textInputContainer: {
                  backgroundColor: 'rgba(0,0,0,0)',
                  borderTopWidth: 0,
                  borderBottomWidth:0
                },
                textInput: {
                  marginLeft: 0,
                  marginRight: 0,
                  height: 38,
                  color: '#2A2A2A',
                  backgroundColor: 'rgba(255,255,255,0.7)',
                  fontSize: 16
                },
                listView: {
                  backgroundColor: 'rgba(255,255,255,0.7)',
                },
                poweredContainer: {
                  backgroundColor: 'rgba(255,255,255,0.2)',
                },
                predefinedPlacesDescription: {
                  color: '#2B60DB',
                },
              }}

              currentLocation={false} // Will add a 'Current location' button at the top of the predefined places list
              currentLocationLabel="Current location"
              nearbyPlacesAPI='GooglePlacesSearch' // Which API to use: GoogleReverseGeocoding or GooglePlacesSearch
              GoogleReverseGeocodingQuery={{
                // available options for GoogleReverseGeocoding API : https://developers.google.com/maps/documentation/geocoding/intro
              }}
              GooglePlacesSearchQuery={{
                // available options for GooglePlacesSearch API : https://developers.google.com/places/web-service/search
                rankby: 'distance',
              }}
              filterReverseGeocodingByTypes={['locality', 'administrative_area_level_3']} // filter the reverse geocoding results by types - ['locality', 'administrative_area_level_3'] if you want to display only cities
              debounce={200} // debounce the requests in ms. Set to 0 to remove debounce. By default 200ms.
            />
            <View style={styles.center}>
              <Icon name="md-pin" size={60} color="#547983"/>
            </View>
            <ActionButton buttonColor="#547983">
              <ActionButton.Item buttonColor='rgb(28,28,28)' onPress={() => console.log("notes tapped!")}>
                <Icon name="md-help-circle" style={styles.actionButtonIcon} />
              </ActionButton.Item>
              <ActionButton.Item 
                buttonColor='rgb(28,28,28)' 
                title="Select Location" 
                onPress={ _ => {
                  this.setState({ 
                    promptVisible: true,
                  })
                }}
              >
                <Icon name="md-checkbox" style={styles.actionButtonIcon} />
              </ActionButton.Item>
              <ActionButton.Item buttonColor='rgb(28,28,28)' title="Cancel" onPress={() => {Actions.pop();}}>
                <Icon name="ios-undo" style={styles.actionButtonIcon} />
              </ActionButton.Item>
            </ActionButton>
          </View>
          <Prompt
              title="New Location Name"
              placeholder="Start typing"
              //defaultValue={this.state.defaultText}
              visible={this.state.promptVisible}
              onCancel={() => this.setState({ promptVisible: false})}
              onSubmit={(value) => 
                {
                  this.setState({ promptVisible: false})
                  //
                  newPlans = [...this.props.plans];
                  newPlans[this.props.planId].locations.push(
                    {
                      name: value,
                      latitude: this.state.region.latitude,
                      longitude: this.state.region.longitude,
                    }
                  );
                  this.props.updatePlans(newPlans);
                  Actions.pop()
                }
              }/>
        </MapView>
      );
    }
  }
}


const mapDispatchToProps = (dispatch) => {
  return {
    updatePlans: (plans) => {
      dispatch(actions.updatePlans({plans}));
    }
  }
}

const mapStateToProps = (state) => {
  return {
    plans: state.db.plans,
  }
}


const styles = StyleSheet.create({
  actionButtonIcon: {
    fontSize: 25,
    height: 30,
    color: 'white',
  },
  center: {
    position: 'absolute',
    top: deviceScreen.height/2-30,
    left: deviceScreen.width/2-15,
    backgroundColor: 'rgba(0,0,0,0)'
  },
  spinner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#25303D'
  }
});

export default connect(mapStateToProps, mapDispatchToProps)(LocationFinder);