import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Dimensions,
  Animated,
  Text
} from 'react-native';

import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import MapView from 'react-native-maps';
import ActionButton from 'react-native-action-button';
import Icon from 'react-native-vector-icons/Ionicons';
import {Actions} from 'react-native-router-flux';
import Spinner from 'react-native-spinkit';
import Prompt from 'react-native-prompt';
import clusterfck from 'clusterfck';
import enclose from 'circle-enclose';
import Slider from 'react-native-slider';

const deviceScreen = Dimensions.get('window');
const ASPECT_RATIO = deviceScreen.width / deviceScreen.height;
const LATITUDE = 25.0454863;
const LONGITUDE = 121.5289386;
const LATITUDE_DELTA = 0.02;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;
const SPACE = 0.01;

const DEFAULT_PADDING = { top: 40, right: 40, bottom: 40, left: 40 };

const mapStyle = [
  {
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#242f3e"
      }
    ]
  },
  {
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#746855"
      }
    ]
  },
  {
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#242f3e"
      }
    ]
  },
  {
    "featureType": "administrative.locality",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#d59563"
      }
    ]
  },
  {
    "featureType": "poi",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#d59563"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#263c3f"
      }
    ]
  },
  {
    "featureType": "poi.park",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#6b9a76"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#38414e"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#212a37"
      }
    ]
  },
  {
    "featureType": "road",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#9ca5b3"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#746855"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "geometry.stroke",
    "stylers": [
      {
        "color": "#1f2835"
      }
    ]
  },
  {
    "featureType": "road.highway",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#f3d19c"
      }
    ]
  },
  {
    "featureType": "transit",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#2f3948"
      }
    ]
  },
  {
    "featureType": "transit.station",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#d59563"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "geometry",
    "stylers": [
      {
        "color": "#17263c"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.fill",
    "stylers": [
      {
        "color": "#515c6d"
      }
    ]
  },
  {
    "featureType": "water",
    "elementType": "labels.text.stroke",
    "stylers": [
      {
        "color": "#17263c"
      }
    ]
  }
];

const colorMap = [
  'rgba(229, 63, 69, 0.4)',
  'rgba(252, 228, 168, 0.4)',
  'rgba(133, 168, 148, 0.4)',
  'rgba(62, 107, 126, 0.4)',
  'rgba(94, 80, 63, 0.5)',
]

export default class RecommendMap extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      mask: '#25303D',
      circles: [],
      region: {
        latitude: LATITUDE,
        longitude: LONGITUDE,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      },
      defaultText: '',
      promptVisible: false,
      MARKERS: this.props.markers,
      allLocations: this.props.markers.map((item)=>{
        return[item.latitude, item.longitude];
      }),
      value: 1,
    };
    this.fitAllMarkers = this.fitAllMarkers.bind(this);
    this.getCircleId = this.getCircleId.bind(this);  
    this.onMapPress = this.onMapPress.bind(this);  
  }

  componentDidMount(){
    setTimeout(()=> {this.setState({loading: false})}, 700);
    setTimeout(()=> {this.setState({mask: 'rgba(0,0,0,0)'})}, 1000);
    setTimeout(()=> {this.fitAllMarkers();}, 600); 
    setTimeout(()=> {this.calculateRegion();}, 1000); 
  }

  shouldComponentUpdate(nextProps, nextState){
    if(nextState.circles.length > 0 && typeof(nextState.circles[0].latitude) == true)
      return false;
    //console.log(nextState);
    this.calculateRegion();
    return true;
  }

  fitAllMarkers() { 
    this.map.fitToCoordinates(this.state.MARKERS, {
      edgePadding: DEFAULT_PADDING,
      animated: true,
    });
  }

  calculateRegion() {
    clusters = clusterfck.kmeans(this.state.allLocations, this.state.value);
    coordinatesGroup = clusters.map((item)=>{
      return item.map((pair)=>{
        return{
          x: pair[0],
          y: pair[1],
          r: 0.0001
        }
      });
    });

    circles = coordinatesGroup.map((group)=>{
      circle = enclose(group)
      return {
        latitude: circle.x,
        longitude: circle.y,
        radius: circle.r,
      }
    });
    this.setState({ circles });
  }

  onRegionChange(region) {
    if(this.state.mask != 'rgba(0,0,0,0)')
      return;
    this.setState({ region });
  }

  convertRegion(latitude, longitude) {
    const { region } = this.state;
    _region = {
      ...this.state.region,
      latitude: latitude,
      longitude: longitude,
    };
    return _region;
  }

  renderLoading() {
    return (
      <View style={styles.spinner}>
        <Spinner isVisible={true}
                 size={70}
                 type={'FadingCircle'}
                 color={'#3C4F5E'}/>
      </View>
    );
  }

  getCircleId(coordinate) {
    for (i = 0; i < this.state.circles.length; i++) {
      deltaX = coordinate.latitude - this.state.circles[i].latitude;
      deltaY = coordinate.longitude - this.state.circles[i].longitude;
      if( Math.sqrt(Math.pow(deltaX, 2) + (Math.pow(deltaY, 2)))< this.state.circles[i].radius )
        return i;
    }
    return -1;
  }

  onMapPress(e) {
    if(e.nativeEvent.coordinate != undefined)
    {
      circleId = this.getCircleId(e.nativeEvent.coordinate);
      console.log(circleId);
      Actions.pop({duration:0});
    }
  }

  render() {
    if (this.state.loading) {
      return this.renderLoading();
    }
    else
    {
      return (
        <MapView
          ref={ref => { this.map = ref; }}
          provider={MapView.PROVIDER_GOOGLE}
          customMapStyle={mapStyle}
          style={{
            backgroundColor: '#25303D',
            ...StyleSheet.absoluteFillObject,
          }}
          onPress={this.onMapPress}
          //region={this.state.region}
          //onRegionChange={region => this.onRegionChange(region)}
          >
          {this.state.MARKERS.map((marker, i) => (
            <MapView.Marker
              key={i}
              coordinate={marker}
            />
          ))}
          {this.state.circles.map((item, i) => {
            _center = {latitude:item.latitude,longitude:item.longitude};
            return (
              <MapView.Circle
                key={i}
                center={_center}
                radius={item.radius*110.574*1000}
                fillColor= {colorMap[i%5]}
                strokeColor="rgba(0,0,0,0.0)"
                zIndex={0}
                //strokeWidth={2}
              />
              )
            }
          )}
          <View style={{...StyleSheet.absoluteFillObject}} 
                pointerEvents={'box-none'}
                backgroundColor={this.state.mask}
          >
            <View style={styles.slider}>
              <View style={{height:30}}>
                <Text style={styles.value}>Hotels: {this.state.value}</Text>
              </View>
              <Slider
                trackStyle={customStyles4.track}
                thumbStyle={customStyles4.thumb}
                minimumValue={1}
                maximumValue={6}
                thumbTintColor='#F00'
                step={1}
                value={this.state.value}
                onValueChange={(value) => this.setState({value})} />
            </View>
            <ActionButton buttonColor="#547983">
              <ActionButton.Item buttonColor='rgb(28,28,28)' title="Cancel" onPress={() => {Actions.pop();}}>
                <Icon name="ios-undo" style={styles.actionButtonIcon} />
              </ActionButton.Item>
            </ActionButton>
          </View>
        </MapView>
      );
    }
  }
}


var customStyles4 = StyleSheet.create({
  track: {
    height: 2,
    borderRadius: 1,
    marginTop: -30,
  },
  thumb: {
    width: 30,
    height: 30,
    borderRadius: 30 / 2,
    backgroundColor: 'white',
    shadowColor: 'black',
    shadowOffset: {width: 0, height: 2},
    shadowRadius: 2,
    shadowOpacity: 0.35,
  }
});


const styles = StyleSheet.create({
  actionButtonIcon: {
    fontSize: 25,
    height: 30,
    color: 'white',
  },
  spinner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#25303D'
  },
  value: {
    color: 'white'
  },
  slider: {
    position: 'absolute',
    bottom: 20,
    left: 10,
    width: deviceScreen.width - 110,
    alignItems: 'stretch',
    justifyContent: 'center',
  }
});