import React, { Component } from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  Button,
  Dimensions,
  TouchableOpacity
} from 'react-native';

import {Actions} from 'react-native-router-flux';
import Icon from 'react-native-vector-icons/Ionicons';

const deviceScreen = Dimensions.get('window');

export default class ImportPage extends Component {
  render() {
    return (
      <Image source={require('../../../resources/img/ImportPage.png')} style={styles.container}>
      </Image>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    height: deviceScreen.height,
    width: deviceScreen.width,
    resizeMode: 'cover',
    backgroundColor: 'rgba(0,0,0,0)'
  },
  topCloseButton: {
    position: 'absolute',
    top: 30,
    left: 310,
    height: 90,
    width: 90,
  },
  icon: {
    fontSize: 30,
    height: 35,
    color: 'black',
  },
});
