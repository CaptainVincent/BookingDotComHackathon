import * as types from '../actions/ActionTypes';

const initialState = [
]

export default db = (state = initialState, action)  => {
  switch (action.type) {
  case types.UPDATE_PLAN:
    return {
      ...state,
      ...action.plans
    }
  default:
    return state
  }
}
