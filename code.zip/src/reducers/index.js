import { combineReducers } from 'redux';
import db from './db';
/*
const stateTemplate = {
  plan: [
    {
      planName: '',
      planDescription: '',
      center: {
        latitude: 0,
        longitude: 0,
      }
      position: [
        { 
          latitude: 0,
          longitude: 0,
        }
      ],
      locations: [
        {
          locationName: '',
          locationDescription: '',
          latitude: 0,
          longitude: 0,
          lastUpdated: 0
        },
      }
    }
  ],
  bookingDotCom: {
    isFetching: false,
    didInvalidate: false,
    items: [],
    lastUpdated: 0
  },
};
*/

export default combineReducers({
  db,
})
